// Look in ./config for karma.conf.js
module.exports = require('./tests/karma.conf.js');