/*
    Adapted from ng2-translate
    Temporary file for referencing the TypeScript defs for Jasmine + some potentially
    utils for testing. Will change/adjust this once I find a better way of doing
 */

declare module jasmine {
    interface Matchers {
        toHaveText(text: string): boolean;
        toContainText(text: string): boolean;
    }
}

beforeEach(() => {
    jasmine.addMatchers({

        toHaveText: function() {
            return {
                compare: function(actual, expectedText) {
                    let actualText = actual.textContent;
                    return {
                        pass: actualText === expectedText,
                        get message() {
                            return 'Expected ' + actualText + ' to equal ' + expectedText;
                        }
                    };
                }
            };
        },

        toContainText: function() {
            return {
                compare: function(actual, expectedText) {
                    let actualText = actual.textContent;
                    return {
                        pass: actualText.indexOf(expectedText) > -1,
                        get message() {
                            return 'Expected ' + actualText + ' to contain ' + expectedText;
                        }
                    };
                }
            };
        }
    });
});