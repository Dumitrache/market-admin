export interface NotificationType {
  name: string;
  color: string;
}
