import {NgModule} from '@angular/core';
import {PushNotificationsService} from './push-notifications.service';

@NgModule({
    providers: [PushNotificationsService]
})
export class PushNotificationsModule {}